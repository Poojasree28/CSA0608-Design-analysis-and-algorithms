"""
Task 5 - Same graph, different algorithmic reasoning
  5.1 Dijkstra (greedy, non-negative weights)
  5.2 Bellman-Ford (negative edges + negative-cycle detection)
  5.3 Floyd-Warshall (all pairs)
"""
import heapq

INF = float("inf")
V = ["A", "B", "C", "D", "E"]
EDGES = [("A", "B", 4), ("A", "C", 7), ("B", "C", 2), ("B", "D", 6),
         ("C", "D", 1), ("D", "E", 3), ("C", "E", 8)]


def path_to(pred, t):
    p = []
    while t is not None:
        p.append(t)
        t = pred[t]
    return "->".join(reversed(p))


# ---------------------------------------------------------------- 5.1
def dijkstra(vertices, edges, src, verbose=True, allow_negative=False):
    adj = {v: [] for v in vertices}
    for u, v, w in edges:
        if w < 0 and not allow_negative:
            raise ValueError("Dijkstra requires non-negative weights")
        adj[u].append((v, w))
    dist = {v: INF for v in vertices}
    pred = {v: None for v in vertices}
    dist[src] = 0
    done = set()
    pq = [(0, src)]
    while pq:
        d, u = heapq.heappop(pq)              # EXTRACT_MIN: closest unfinalised vertex
        if u in done:
            continue
        done.add(u)                            # greedy commitment: dist[u] is final
        if verbose:
            print(f"Finalise {u} with dist={d}")
        for v, w in adj[u]:                    # relaxation
            if v not in done and dist[u] + w < dist[v]:
                old = dist[v]
                dist[v] = dist[u] + w
                pred[v] = u
                heapq.heappush(pq, (dist[v], v))
                if verbose:
                    print(f"   relax {u}->{v} (w={w}): {old} -> {dist[v]}, pred[{v}]={u}")
            elif verbose and v not in done:
                print(f"   relax {u}->{v} (w={w}): no improvement ({dist[u]+w} >= {dist[v]})")
    return dist, pred


# ---------------------------------------------------------------- 5.2
def bellman_ford(vertices, edges, src, verbose=True):
    dist = {v: INF for v in vertices}
    pred = {v: None for v in vertices}
    dist[src] = 0
    for k in range(1, len(vertices)):          # |V|-1 passes
        changed = False
        for u, v, w in edges:
            if dist[u] != INF and dist[u] + w < dist[v]:
                dist[v] = dist[u] + w
                pred[v] = u
                changed = True
        if verbose:
            print(f"After pass {k}: {dist}")
        if not changed:
            break
    for u, v, w in edges:                      # |V|-th pass: negative cycle test
        if dist[u] != INF and dist[u] + w < dist[v]:
            return dist, pred, True
    return dist, pred, False


# ---------------------------------------------------------------- 5.3
def floyd_warshall(vertices, edges, verbose=True):
    n = len(vertices)
    idx = {v: i for i, v in enumerate(vertices)}
    D = [[INF] * n for _ in range(n)]
    for i in range(n):
        D[i][i] = 0
    for u, v, w in edges:
        D[idx[u]][idx[v]] = w
    for k in range(n):                         # allowed intermediate vertices 0..k
        for i in range(n):
            for j in range(n):
                if D[i][k] + D[k][j] < D[i][j]:
                    D[i][j] = D[i][k] + D[k][j]
        if verbose:
            print(f"\nMatrix after allowing intermediate vertex {vertices[k]}:")
            show(D, vertices)
    return D


def show(D, vertices):
    print("     " + "".join(f"{v:>5}" for v in vertices))
    for i, v in enumerate(vertices):
        print(f"{v:>4} " + "".join(f"{('INF' if x == INF else x):>5}" for x in D[i]))


if __name__ == "__main__":
    print("=========== TASK 5.1 : DIJKSTRA from A ===========")
    dist, pred = dijkstra(V, EDGES, "A")
    print("\nFinal distances :", dist)
    for v in V:
        print(f"  A to {v}: {dist[v]:>3}   path {path_to(pred, v)}")

    print("\n=========== TASK 5.2 : BELLMAN-FORD from A (same graph) ===========")
    d2, p2, neg = bellman_ford(V, EDGES, "A")
    print("Negative cycle reachable?", neg)
    print("Distances:", d2)

    print("\n--- Graph with a NEGATIVE edge C->B = -3 ---")
    V2 = ["A", "B", "C", "D"]
    E_neg = [("A", "B", 1), ("A", "C", 2), ("C", "B", -3), ("B", "D", 2)]
    dd, _ = dijkstra(V2, E_neg, "A", verbose=False, allow_negative=True)
    print("Dijkstra (UNSAFE here)  :", dd, "  <- B and D are WRONG (B was finalised at 1)")
    d3, p3, neg3 = bellman_ford(V2, E_neg, "A", verbose=False)
    print("Bellman-Ford (correct)  :", d3, "| negative cycle:", neg3)
    print("Correct path to D:", path_to(p3, "D"))

    print("\n--- Graph with a reachable NEGATIVE CYCLE (B->C->B total = -1) ---")
    E_cyc = [("A", "B", 1), ("B", "C", -3), ("C", "B", 2), ("C", "D", 1)]
    d4, p4, neg4 = bellman_ford(["A", "B", "C", "D"], E_cyc, "A", verbose=False)
    print("Negative cycle detected?", neg4, "(expected True)")

    print("\n=========== TASK 5.3 : FLOYD-WARSHALL (all pairs) ===========")
    D = floyd_warshall(V, EDGES)
    print("\nFINAL all-pairs shortest distance matrix:")
    show(D, V)
