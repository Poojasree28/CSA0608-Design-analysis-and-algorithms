"""
Task 1 - Repaired LoadVehicle algorithm (Fractional Knapsack, Greedy)
Run in any online Python compiler / IDLE (Python 3).
Greedy-choice rule: always take the package with the highest value/weight ratio.
"""

def load_vehicle(packages, capacity):
    """packages: list of (id, weight, value). Returns (total_value, plan)."""
    if capacity < 0:
        raise ValueError("Capacity must be non-negative")
    for pid, w, v in packages:
        if w <= 0 or v < 0:
            raise ValueError(f"Invalid package {pid}: weight must be >0 and value >=0")

    items = [(pid, w, v, v / w) for pid, w, v in packages]   # ratio value/weight
    items.sort(key=lambda x: (-x[3], x[1]))                  # descending ratio

    remaining = capacity
    total = 0.0
    plan = []
    print(f"{'Pkg':<5}{'W':>4}{'V':>6}{'Ratio':>8}")
    for pid, w, v, r in items:
        print(f"{pid:<5}{w:>4}{v:>6}{r:>8.2f}")
    print("\n--- Greedy trace ---")
    for pid, w, v, r in items:
        if remaining == 0:                       # termination: vehicle full
            break
        if w <= remaining:                       # whole package fits
            frac, loaded, gain = 1.0, w, v
        else:                                    # partial package
            frac = remaining / w
            loaded, gain = remaining, v * frac
        remaining -= loaded
        total += gain
        plan.append((pid, frac, loaded, gain))
        print(f"Take {pid}: fraction={frac:.3f}, weight={loaded}, gain={gain:.2f}, "
              f"remaining capacity={remaining}, total={total:.2f}")
    return total, plan


if __name__ == "__main__":
    print("=== TEST 1: textbook instance, capacity 50 ===")
    pk = [("P1", 10, 60), ("P2", 20, 100), ("P3", 30, 120)]
    t, plan = load_vehicle(pk, 50)
    print("Maximum value =", round(t, 2), "(expected 240.00)\n")

    print("=== TEST 2: capacity larger than total weight ===")
    t, plan = load_vehicle(pk, 100)
    print("Maximum value =", round(t, 2), "(expected 280.00)\n")

    print("=== TEST 3: capacity 0 ===")
    t, plan = load_vehicle(pk, 0)
    print("Maximum value =", round(t, 2), "(expected 0.00)\n")

    print("=== TEST 4: single package, partial load ===")
    t, plan = load_vehicle([("X", 8, 40)], 4)
    print("Maximum value =", round(t, 2), "(expected 20.00)")
