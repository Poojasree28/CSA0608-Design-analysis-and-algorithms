"""
Task 4 - Pseudocode Forensics: Word Break
Faulty  : sets DP[i]=TRUE when substring(j,i) is a word, WITHOUT checking DP[j].
Repaired: requires  DP[j] == TRUE  AND  substring(j,i) in Dictionary.
substring(Text, j, i) = Text[j:i]  (characters j+1 .. i, 1-indexed)
"""

def word_break_faulty(text, dictionary, trace=False):
    n = len(text)
    dp = [False] * (n + 1)
    dp[0] = True
    for i in range(1, n + 1):
        dp[i] = False
        for j in range(0, i):
            if text[j:i] in dictionary:          # DEFECT: DP[j] is never checked
                dp[i] = True
                if trace:
                    print(f"  FAULTY i={i}: text[{j}:{i}]='{text[j:i]}' in dict -> DP[{i}]=TRUE  (but DP[{j}]={dp[j]})")
                break
        if trace and not dp[i]:
            print(f"  FAULTY i={i}: no word ends here -> DP[{i}]=FALSE")
    return dp[n], dp


def word_break_fixed(text, dictionary, trace=False):
    n = len(text)
    dp = [False] * (n + 1)
    dp[0] = True
    for i in range(1, n + 1):
        dp[i] = False
        for j in range(0, i):
            if dp[j] and text[j:i] in dictionary:   # REPAIR: add dp[j] check
                dp[i] = True
                if trace:
                    print(f"  FIXED  i={i}: DP[{j}]=TRUE and text[{j}:{i}]='{text[j:i]}' in dict -> DP[{i}]=TRUE")
                break
        if trace and not dp[i]:
            print(f"  FIXED  i={i}: no valid split -> DP[{i}]=FALSE")
    return dp[n], dp


def run(title, text, dictionary, expected):
    print(f"--- {title} ---")
    print(f"Text='{text}'  Dictionary={sorted(dictionary)}  Correct answer={expected}")
    f, dpf = word_break_faulty(text, dictionary, trace=True)
    g, dpg = word_break_fixed(text, dictionary, trace=True)
    print(f"  Faulty DP = {dpf} -> {f}")
    print(f"  Fixed  DP = {dpg} -> {g}")
    print(f"  Faulty correct? {f == expected} | Fixed correct? {g == expected}\n")


if __name__ == "__main__":
    run("TASK 4.2 Failing input", "abcd", {"cd"}, False)                    # faulty says True
    run("TASK 4.4 Regression (TRUE case)", "applepen", {"apple", "pen"}, True)
    run("EXTRA Regression (FALSE case)", "xyz", {"a", "b"}, False)
    run("EXTRA classic", "leetcode", {"leet", "code"}, True)
    run("EXTRA classic 2", "catsandog", {"cats", "dog", "sand", "and", "cat"}, False)
