"""
Task 6 - Energy-Aware Job Scheduling (Design Challenge)
Problem : Weighted Interval Scheduling.
Strategy: Dynamic Programming (a greedy rule is NOT safe - see Stage 6).
State   : OPT[i] = max energy-saving value obtainable from the first i jobs
          after sorting jobs by finish time (OPT[0] = 0).
p(i)    : largest index j < i whose finish time <= start time of job i (0 if none).
Recurr. : OPT[i] = max( OPT[i-1],              # exclude job i
                        value[i] + OPT[p(i)] ) # include job i
"""
import bisect
import itertools
import random


def schedule(jobs, verbose=True):
    """jobs: list of (name, start, finish, value) -> (best_value, selected_names)"""
    jobs = sorted(jobs, key=lambda j: (j[2], j[1]))          # sort by finish time
    n = len(jobs)
    finishes = [j[2] for j in jobs]
    p = [0] * (n + 1)
    for i in range(1, n + 1):
        # number of jobs among first i-1 whose finish <= start of job i
        p[i] = bisect.bisect_right(finishes, jobs[i - 1][1], 0, i - 1)
    OPT = [0] * (n + 1)
    take = [False] * (n + 1)
    if verbose:
        print(f"{'i':<3}{'Job':<5}{'Start':>6}{'Fin':>5}{'Val':>5}{'p(i)':>6}")
        for i in range(1, n + 1):
            nm, s, f, v = jobs[i - 1]
            print(f"{i:<3}{nm:<5}{s:>6}{f:>5}{v:>5}{p[i]:>6}")
        print("\n--- DP computation ---")
    for i in range(1, n + 1):
        nm, s, f, v = jobs[i - 1]
        excl = OPT[i - 1]
        incl = v + OPT[p[i]]
        if incl > excl:
            OPT[i], take[i] = incl, True
        else:
            OPT[i], take[i] = excl, False
        if verbose:
            print(f"OPT[{i}] ({nm}): exclude={excl}, include={v}+OPT[{p[i]}]={incl} "
                  f"-> OPT[{i}]={OPT[i]} ({'INCLUDE' if take[i] else 'EXCLUDE'})")
    # reconstruction
    chosen, i = [], n
    while i > 0:
        if take[i]:
            chosen.append(jobs[i - 1][0])
            i = p[i]
        else:
            i -= 1
    chosen.reverse()
    if verbose:
        print("\nOPT array:", OPT)
    return OPT[n], chosen


def brute_force(jobs):
    best = 0
    for r in range(len(jobs) + 1):
        for combo in itertools.combinations(jobs, r):
            ok = all(a[2] <= b[1] or b[2] <= a[1] for a, b in itertools.combinations(combo, 2))
            if ok:
                best = max(best, sum(c[3] for c in combo))
    return best


def greedy_generic(jobs, key):
    """Pick jobs in the order given by key, keep a job if it overlaps nothing chosen."""
    chosen = []
    for j in sorted(jobs, key=key):
        if all(j[2] <= c[1] or c[2] <= j[1] for c in chosen):
            chosen.append(j)
    return [c[0] for c in chosen], sum(c[3] for c in chosen)


if __name__ == "__main__":
    print("=========== STAGE 5 : DESK-CHECK ON THE 8-JOB DATASET ===========")
    data = [("J1", 1, 3, 20), ("J2", 2, 5, 50), ("J3", 4, 6, 30), ("J4", 6, 8, 40),
            ("J5", 5, 9, 60), ("J6", 8, 10, 30), ("J7", 9, 11, 50), ("J8", 11, 13, 40)]
    best, sel = schedule(data)
    print("\nSelected jobs      :", sel)
    print("Maximum energy value:", best, "(expected 200)")
    print("Brute-force check  :", brute_force(data))

    print("\n=========== STAGE 6 : ADVERSARIAL DATASET ===========")
    adv = [("K1", 1, 3, 10), ("K2", 3, 5, 10), ("K3", 5, 7, 10), ("K4", 7, 9, 10),
           ("K5", 1, 9, 45), ("K6", 2, 6, 30), ("K7", 6, 10, 30)]
    print("Jobs:", adv)
    ef_sel, ef_val = greedy_generic(adv, key=lambda j: (j[2], j[1]))
    hv_sel, hv_val = greedy_generic(adv, key=lambda j: -j[3])
    sd_sel, sd_val = greedy_generic(adv, key=lambda j: (j[2] - j[1]))
    print(f"Greedy earliest-finish : {ef_sel} value={ef_val}")
    print(f"Greedy highest-value   : {hv_sel} value={hv_val}")
    print(f"Greedy shortest-job    : {sd_sel} value={sd_val}")
    print("\nDP algorithm trace:")
    best, sel = schedule(adv)
    print("DP selected:", sel, "value =", best)
    print("Brute-force optimum:", brute_force(adv))

    print("\n=========== EXTRA TESTS ===========")
    print("Same greedy rules on the 8-job dataset:")
    print("  earliest-finish:", greedy_generic(data, key=lambda j: (j[2], j[1])))
    print("  highest-value  :", greedy_generic(data, key=lambda j: -j[3]))
    print("Boundary: single job            ->", schedule([("X", 1, 2, 7)], verbose=False))
    print("Boundary: all jobs overlap      ->", schedule([("A", 1, 5, 3), ("B", 2, 6, 9), ("C", 3, 7, 4)], verbose=False))
    print("Boundary: touching (finish=start)->", schedule([("A", 1, 3, 5), ("B", 3, 5, 6)], verbose=False))
    print("Boundary: identical intervals   ->", schedule([("A", 1, 3, 5), ("B", 1, 3, 8)], verbose=False))

    random.seed(7)
    ok = 0
    for _ in range(300):
        k = random.randint(1, 8)
        jobs = []
        for t in range(k):
            s = random.randint(0, 12)
            jobs.append((f"R{t}", s, s + random.randint(1, 6), random.randint(1, 50)))
        v, _ = schedule(jobs, verbose=False)
        assert v == brute_force(jobs), jobs
        ok += 1
    print(f"Randomised verification: DP == brute force on {ok}/300 random instances")
