"""
Task 2 - Job Sequencing with Deadlines (Greedy)
Greedy rule: consider jobs in descending order of profit; place each job in the
LATEST free slot on or before its deadline; reject it if no such slot exists.
"""

def job_sequencing(jobs, verbose=True):
    """jobs: list of (id, deadline, profit). Returns (schedule list, total profit)."""
    jobs_sorted = sorted(jobs, key=lambda j: -j[2])
    max_d = max(j[1] for j in jobs)
    slots = [None] * (max_d + 1)                  # slots[1..max_d]
    total = 0
    if verbose:
        print("Sorted by profit:", [(j[0], j[1], j[2]) for j in jobs_sorted])
        print("Initial slots:", slots[1:])
    for jid, d, p in jobs_sorted:
        placed = False
        for s in range(min(d, max_d), 0, -1):     # latest free slot <= deadline
            if slots[s] is None:
                slots[s] = jid
                total += p
                placed = True
                if verbose:
                    print(f"Job {jid} (d={d}, p={p}) -> slot {s}; profit={total}; slots={slots[1:]}")
                break
        if not placed and verbose:
            print(f"Job {jid} (d={d}, p={p}) -> REJECTED (no free slot <= {d}); slots={slots[1:]}")
    schedule = [(s, slots[s]) for s in range(1, max_d + 1) if slots[s] is not None]
    return schedule, total


if __name__ == "__main__":
    print("=== TASK 2.4: Given instance ===")
    given = [("A", 2, 80), ("B", 1, 35), ("C", 2, 60), ("D", 3, 40), ("E", 1, 25)]
    sch, tot = job_sequencing(given)
    print("Schedule (slot, job):", sch)
    print("Total profit =", tot, "(expected 180)\n")

    print("=== TASK 2.5: Challenge - change profit of B from 35 to 70 ===")
    print("Prediction: B now precedes C, takes slot 1, C is rejected -> profit 190")
    changed = [("A", 2, 80), ("B", 1, 70), ("C", 2, 60), ("D", 3, 40), ("E", 1, 25)]
    sch, tot = job_sequencing(changed)
    print("Schedule (slot, job):", sch)
    print("Total profit =", tot, "(expected 190)\n")

    print("=== EXTRA TEST: all deadlines = 1 (only best job fits) ===")
    sch, tot = job_sequencing([("X", 1, 10), ("Y", 1, 50), ("Z", 1, 30)])
    print("Schedule:", sch, "Total =", tot)
