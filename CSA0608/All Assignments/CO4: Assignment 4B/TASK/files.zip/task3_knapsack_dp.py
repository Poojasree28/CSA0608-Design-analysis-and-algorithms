"""
Task 3 - 0/1 Knapsack by Dynamic Programming (with item reconstruction)
State  : K[i][w] = max value using only the first i items with capacity w
Recurr.: K[i][w] = K[i-1][w]                                  if wt[i] > w
         K[i][w] = max(K[i-1][w], val[i] + K[i-1][w-wt[i]])   otherwise
Base   : K[0][w] = 0 and K[i][0] = 0
"""

def knapsack(items, W, show=True):
    n = len(items)
    K = [[0] * (W + 1) for _ in range(n + 1)]
    for i in range(1, n + 1):                      # item order = dependency order
        name, wt, val = items[i - 1]
        for w in range(0, W + 1):
            if wt > w:
                K[i][w] = K[i - 1][w]
            else:
                K[i][w] = max(K[i - 1][w], val + K[i - 1][w - wt])
    if show:
        print("DP table K[i][w]  (rows = items considered, columns = capacity)")
        print("          " + "".join(f"w={w:<4}" for w in range(W + 1)))
        for i in range(n + 1):
            label = "none " if i == 0 else f"{items[i-1][0]:<5}"
            print(f"i={i} {label} " + "".join(f"{K[i][w]:<5}" for w in range(W + 1)))

    chosen, w = [], W
    if show:
        print("\nBacktracking:")
    for i in range(n, 0, -1):
        name, wt, val = items[i - 1]
        if K[i][w] != K[i - 1][w]:
            chosen.append(name)
            if show:
                print(f"i={i} ({name}): K[{i}][{w}]={K[i][w]} != K[{i-1}][{w}]={K[i-1][w]} -> TAKE {name}, w becomes {w - wt}")
            w -= wt
        elif show:
            print(f"i={i} ({name}): K[{i}][{w}]={K[i][w]} == K[{i-1}][{w}] -> SKIP {name}")
    chosen.reverse()
    return K[n][W], chosen


if __name__ == "__main__":
    print("=== TASK 3.4: Given instance, capacity 7 ===")
    items = [("P", 2, 12), ("Q", 3, 20), ("R", 4, 25), ("S", 5, 30)]
    best, chosen = knapsack(items, 7)
    print("\nOptimum value =", best, "| Items selected =", chosen,
          "| Total weight =", sum(w for n, w, v in items if n in chosen))
    print("Expected: 45 with Q and R\n")

    print("=== TEST: capacity smaller than every item ===")
    best, chosen = knapsack(items, 1, show=False)
    print("Optimum =", best, "Items =", chosen, "(expected 0, [])\n")

    print("=== TEST: capacity big enough for all ===")
    best, chosen = knapsack(items, 14, show=False)
    print("Optimum =", best, "Items =", chosen, "(expected 87, all)\n")

    print("=== TEST: classic instance (cap 50) ===")
    trap = [("A", 10, 60), ("B", 20, 100), ("C", 30, 120)]
    best, chosen = knapsack(trap, 50, show=False)
    print("Optimum =", best, "Items =", chosen, "(expected 220 = B+C; fractional would give 240)")
